from django.contrib import admin
from django.urls import path,include
from productos import views

urlpatterns = [
    path('',views.productos_index,name="productos_index"),
    path('index/',views.productos_index,name="productos_index"),
    path('productos/', views.productos_catalogo,name="productos_catalogo"),
    path("<int:pk>/",views.productos_detail,name="productos_detail"),
]
